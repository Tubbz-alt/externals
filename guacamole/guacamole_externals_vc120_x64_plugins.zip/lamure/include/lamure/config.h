// Copyright (c) 2014 Bauhaus-Universitaet Weimar
// This Software is distributed under the Modified BSD License, see license.txt.
//
// Virtual Reality and Visualization Research Group 
// Faculty of Media, Bauhaus-Universitaet Weimar
// http://www.uni-weimar.de/medien/vr

#ifndef COMMON_CONFIG_IN_HPP
#define COMMON_CONFIG_IN_HPP

#define LAMURE_SHADERS_DIR "F:/repositories/lamure github/install/share/lamure/shaders"
#define LAMURE_FONTS_DIR "F:/repositories/lamure github/install/share/lamure/fonts"

#endif  // COMMON_CONFIG_IN_HPP
