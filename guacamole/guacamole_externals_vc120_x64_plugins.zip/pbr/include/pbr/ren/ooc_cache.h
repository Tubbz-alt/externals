// Copyright (c) 2014 Bauhaus-Universitaet Weimar
// This Software is distributed under the Modified BSD License, see license.txt.
//
// Virtual Reality and Visualization Research Group 
// Faculty of Media, Bauhaus-Universitaet Weimar
// http://www.uni-weimar.de/medien/vr

#ifndef REN_OOC_CACHE_H_
#define REN_OOC_CACHE_H_

#include <map>
#include <queue>
#include <pbr/utils.h>
#include <pbr/ren/config.h>
#include <pbr/ren/cache.h>
#include <pbr/ren/ooc_pool.h>

#include <pbr/ren/platform.h>
#include <pbr/ren/model_database.h>
#include <pbr/ren/policy.h>


namespace pbr {
namespace ren {

class RENDERING_DLL OocCache : public Cache
{
public:

                        OocCache(const OocCache&) = delete;
                        OocCache& operator=(const OocCache&) = delete;
    virtual             ~OocCache();

    static OocCache*    GetInstance();

    void                RegisterNode(const model_t model_id, const node_t node_id, const int32_t priority);
    char*               NodeData(const model_t model_id, const node_t node_id);

    const bool          IsNodeResidentAndAquired(const model_t model_id, const node_t node_id);

    void                Refresh();
    void                Shutdown();

    void                LockPool();
    void                UnlockPool();

    void                StartMeasure();
    void                EndMeasure();

protected:

                        OocCache(const size_t num_slots);
    static bool         is_instanced_;
    static OocCache*    single_;

private:
    static std::mutex   mutex_;

    char*               cache_data_;
    uint32_t            maintenance_counter_;
    OocPool*            pool_;
};


} } // namespace pbr


#endif // REN_OOC_CACHE_H_
