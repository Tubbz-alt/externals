// Copyright (c) 2014 Bauhaus-Universitaet Weimar
// This Software is distributed under the Modified BSD License, see license.txt.
//
// Virtual Reality and Visualization Research Group 
// Faculty of Media, Bauhaus-Universitaet Weimar
// http://www.uni-weimar.de/medien/vr

#ifndef REN_MODEL_DATABASE_H_
#define REN_MODEL_DATABASE_H_

#include <unordered_map>
#include <mutex>

#include <pbr/utils.h>
#include <pbr/types.h>
#include <pbr/ren/lod_point_cloud.h>
#include <pbr/ren/config.h>
#include <pbr/ren/platform.h>

#include <scm/gl_core/query_objects.h>

namespace pbr {
namespace ren {

class RENDERING_DLL ModelDatabase
{
public:

                        ModelDatabase(const ModelDatabase&) = delete;
                        ModelDatabase& operator=(const ModelDatabase&) = delete;
    virtual             ~ModelDatabase();

    static ModelDatabase* GetInstance();

    const model_t       AddModel(const std::string& filepath, const std::string& model_key);
    LodPointCloud*      GetModel(const model_t model_id);
    void                Apply();

    const model_t       num_models() const { std::lock_guard<std::mutex> lock(mutex_); return num_models_; };
    const size_t        size_of_surfel() const { std::lock_guard<std::mutex> lock(mutex_); return size_of_surfel_; };
    const size_t        surfels_per_node() const { std::lock_guard<std::mutex> lock(mutex_); return surfels_per_node_; };

    void                set_window_width(const int32_t window_width) { window_width_ = window_width; };
    void                set_window_height(const int32_t window_height) { window_height_ = window_height; };
    const int32_t       window_width() const { return window_width_; };
    const int32_t       window_height() const { return window_height_; };


protected:

                        ModelDatabase();
    static bool         is_instanced_;
    static ModelDatabase* single_;

private:
    static std::mutex   mutex_;

    std::unordered_map<model_t, LodPointCloud*> models_;

    model_t             num_models_;
    model_t             num_models_pending_;
    size_t              surfels_per_node_;
    size_t              surfels_per_node_pending_;
    size_t              size_of_surfel_;
    
    int32_t             window_width_;
    int32_t             window_height_;

    std::vector<scm::gl::timer_query_ptr> _time_queries;
};


} } // namespace pbr


#endif // REN_MODEL_DATABASE_H_
