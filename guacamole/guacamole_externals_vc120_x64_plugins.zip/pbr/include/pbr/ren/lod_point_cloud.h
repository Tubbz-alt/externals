// Copyright (c) 2014 Bauhaus-Universitaet Weimar
// This Software is distributed under the Modified BSD License, see license.txt.
//
// Virtual Reality and Visualization Research Group 
// Faculty of Media, Bauhaus-Universitaet Weimar
// http://www.uni-weimar.de/medien/vr

#ifndef REN_LOD_POINT_CLOUD_H_
#define REN_LOD_POINT_CLOUD_H_

#include <vector>
#include <fstream>
#include <sstream>

#include <pbr/utils.h>
#include <pbr/types.h>
#include <pbr/ren/platform.h>
#include <pbr/ren/bvh.h>
#include <pbr/ren/config.h>
#include <scm/gl_core/primitives/box.h>

namespace pbr {
namespace ren {

class ModelDatabase;

class RENDERING_DLL LodPointCloud
{

public:

    struct SerializedSurfel
    {
        float x, y, z;
        uint8_t r, g, b, fake;
        float size;
        float nx, ny, nz;
    };

                        LodPointCloud() {};
                        LodPointCloud(const std::string& filename);
    virtual             ~LodPointCloud();

    const model_t       model_id() const { return model_id_; };
    const scm::gl::boxf& aabb() const { return aabb_; };
    const bool          is_loaded() const { return is_loaded_; };
    const Bvh*          bvh() const { return bvh_; };

    void                set_transform(const scm::math::mat4f& transform) { transform_ = transform; };
    const scm::math::mat4f transform() const { return transform_; };

protected:
    void                Load(const std::string& filename);

    friend class        ModelDatabase;
    model_t             model_id_;

private:
    scm::gl::boxf       aabb_;
    bool                is_loaded_;
    Bvh*                bvh_;

    scm::math::mat4f    transform_;

};


} } // namespace pbr


#endif // REN_LOD_POINT_CLOUD_H_
