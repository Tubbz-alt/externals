// Copyright (c) 2014 Bauhaus-Universitaet Weimar
// This Software is distributed under the Modified BSD License, see license.txt.
//
// Virtual Reality and Visualization Research Group 
// Faculty of Media, Bauhaus-Universitaet Weimar
// http://www.uni-weimar.de/medien/vr

#ifndef REN_OOC_DISK_ACCESS_H_
#define REN_OOC_DISK_ACCESS_H_

#include <fstream>
#include <vector>
#include <string>
#include <cstdio>

#include <pbr/ren/platform.h>
#include <pbr/utils.h>
#include <pbr/ren/config.h>

namespace pbr {
namespace ren
{

class RENDERING_DLL OocDiskAccess
{
public:
                        OocDiskAccess();
                        OocDiskAccess(const OocDiskAccess&) = delete;
                        OocDiskAccess& operator=(const OocDiskAccess&) = delete;
    virtual             ~OocDiskAccess();


    void                Open(const std::string& file_name);
    void                OpenForWriting(const std::string& file_name);
    void                Close();
    const bool          is_file_open() const { return is_file_open_; };
    const std::string&  file_name() const { return file_name_; };

    void                Read(char* const data,
                            const size_t start_in_file,
                            const size_t length_in_bytes) const;
                            
    void                Write(char* const data,
                            const size_t start_in_file,
                            const size_t length_in_bytes);

private:
#ifdef PBR_CUT_UPDATE_USE_C_PLUS_PLUS_FOR_LOADING
    mutable std::fstream stream_;
#else
    FILE* stream_;
#endif

    std::string         file_name_;
    bool                is_file_open_;
};

} } // namespace pbr

#endif // REN_OOC_DISK_ACCESS_H_

