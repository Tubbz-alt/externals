// Copyright (c) 2014 Bauhaus-Universitaet Weimar
// This Software is distributed under the Modified BSD License, see license.txt.
//
// Virtual Reality and Visualization Research Group 
// Faculty of Media, Bauhaus-Universitaet Weimar
// http://www.uni-weimar.de/medien/vr

#ifndef REN_CACHE_H_
#define REN_CACHE_H_

#include <map>
#include <queue>
#include <pbr/utils.h>

#include <memory>
#include <mutex>
#include <scm/core.h>
#include <scm/gl_core.h>

#include <pbr/ren/model_database.h>
#include <pbr/ren/policy.h>

#include <pbr/types.h>
#include <pbr/ren/platform.h>
#include <pbr/ren/cache_index.h>

namespace pbr {
namespace ren {

class RENDERING_DLL Cache
{
public:
                        Cache(const Cache&) = delete;
                        Cache& operator=(const Cache&) = delete;
    virtual             ~Cache();

    const bool          IsNodeResident(const model_t model_id, const node_t node_id);

    const slot_t        NumFreeSlots();
    const slot_t        SlotId(const model_t model_id, const node_t node_id);

    const slot_t        num_slots() const { return num_slots_; };
    const slot_t        slot_size() const { return slot_size_; };

    void                Lock();
    void                Unlock();

    void                AquireNode(const context_t context_id, const view_t view_id, const model_t model_id, const node_t node_id);
    void                ReleaseNode(const context_t context_id, const view_t view_id, const model_t model_id, const node_t node_id);
    const bool          ReleaseNodeInvalidate(const context_t context_id, const view_t view_id, const model_t model_id, const node_t node_id);

protected:
                        Cache(const slot_t num_slots);

    CacheIndex*         index_;
    std::mutex          mutex_;

private:
    /* data */

    slot_t              num_slots_;
    node_t              num_nodes_;
    size_t              slot_size_;


};


} } // namespace pbr


#endif // REN_CACHE_H_
