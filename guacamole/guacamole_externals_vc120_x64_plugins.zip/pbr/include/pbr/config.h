// Copyright (c) 2014 Bauhaus-Universitaet Weimar
// This Software is distributed under the Modified BSD License, see license.txt.
//
// Virtual Reality and Visualization Research Group 
// Faculty of Media, Bauhaus-Universitaet Weimar
// http://www.uni-weimar.de/medien/vr

#ifndef COMMON_CONFIG_IN_HPP
#define COMMON_CONFIG_IN_HPP

//#define PBR_INSTALL_DIR "F:/repositories/pitoti-install"
#define PBR_SHADERS_DIR "F:/repositories/pitoti-install/share/pbr/shaders"
#define PBR_FONTS_DIR "F:/repositories/pitoti-install/share/pbr/fonts"

#endif  // COMMON_CONFIG_IN_HPP
