/********************************************************************************
*
* Copyright (C) 2010 Bauhaus University Weimar
*
*********************************************************************************
*
*  module     : gpucast_math.hpp
*
*  description:
*
********************************************************************************/
#ifndef GPUCAST_MATH_HPP
#define GPUCAST_MATH_HPP

// header, system

namespace gpucast { namespace math {

} } // namespace gpucast / namespace math

#endif // GPUCAST_MATH_HPP

