/********************************************************************************
*
* Copyright (C) 2009 Bauhaus-Universitaet Weimar
*
*********************************************************************************
*
*  module     : vec4_impl.hpp
*  project    : glpp
*  description:
*
********************************************************************************/
#ifndef GPUCAST_MATH_VEC_IMPL_HPP
#define GPUCAST_MATH_VEC_IMPL_HPP

namespace gpucast { namespace math {

} } // namespace gpucast / namespace math

#endif