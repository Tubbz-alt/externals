#ifndef GPUCAST_CONFIG_HPP
#define GPUCAST_CONFIG_HPP

#define GPUCAST_INSTALL_DIR "F:/repositories/gpucast-github/gpucast"

#define GPUCAST_GLSL_VERSION_STRING "#version 440\n"

#endif  // GPUCAST_CONFIG_HPP
