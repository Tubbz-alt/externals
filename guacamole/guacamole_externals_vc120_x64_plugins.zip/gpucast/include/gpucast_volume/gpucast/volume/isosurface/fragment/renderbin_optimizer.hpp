/********************************************************************************
*
* Copyright (C) 2007-2012 Bauhaus-Universitaet Weimar
*
*********************************************************************************
*
*  module     : volume_renderer_optimizer.hpp
*  project    : gpucast
*  description:
*
********************************************************************************/
#ifndef GPUCAST_VOLUME_RENDERER_OPTIMIZER_HPP
#define GPUCAST_VOLUME_RENDERER_OPTIMIZER_HPP

// header, system

// header, external

// header, project
#include <gpucast/volume/gpucast.hpp>


namespace gpucast {

class GPUCAST_VOLUME optimizer
{
public : // enums / typedefs

public : // ctors/dtor

  optimizer();
  ~optimizer();

public : // operators

private : // methods

private : // attributes

};

} // namespace gpucast

#endif // GPUCAST_VOLUME_RENDERER_OPTIMIZER_HPP
